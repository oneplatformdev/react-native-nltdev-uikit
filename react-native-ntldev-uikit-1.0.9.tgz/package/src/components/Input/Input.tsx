import React, { forwardRef, memo, useCallback, useMemo, useState } from 'react';
import { Pressable, TextInput, View } from 'react-native';
import type { TextInputProps } from 'react-native';
import { useUITheme } from '../../theme';
import { useScaling } from '../../utils';
import { Typography } from '../Typography';
import { getStyles } from './styles';
import type { InputProps, InputRef } from './types';

const InputComponent = forwardRef<InputRef, InputProps>(
    (
        {
            accessibilityHint,
            accessibilityLabel,
            accessibilityState,
            containerStyle,
            disabled = false,
            editable,
            endAccessory,
            errorText,
            errorTextProps,
            helperText,
            helperTextProps,
            inputContainerStyle,
            invalid = false,
            label,
            labelProps,
            multiline,
            onBlur,
            onFocus,
            passwordToggle,
            placeholderTextColor,
            secureTextEntry,
            startAccessory,
            style,
            ...nativeProps
        },
        ref,
    ) => {
        const { colors, fonts, input } = useUITheme();
        const scaling = useScaling();
        const canTogglePassword = Boolean(secureTextEntry && passwordToggle);
        const [visibility, setVisibility] = useState({ enabled: canTogglePassword, visible: false });
        const [isFocused, setFocused] = useState(false);

        // A changed secure/toggle mode resets visibility before a new mode can render as plain text.
        if (visibility.enabled !== canTogglePassword) {
            setVisibility({ enabled: canTogglePassword, visible: false });
        }

        const isPasswordVisible = canTogglePassword && visibility.enabled && visibility.visible;
        const isInvalid = invalid || Boolean(errorText);
        const styles = useMemo(
            () => getStyles(colors, fonts, input, scaling, isFocused, isInvalid, disabled),
            [colors, disabled, fonts, input, isFocused, isInvalid, scaling],
        );

        const onInputFocus = useCallback<NonNullable<TextInputProps['onFocus']>>(
            event => {
                setFocused(true);
                onFocus?.(event);
            },
            [onFocus],
        );
        const onInputBlur = useCallback<NonNullable<TextInputProps['onBlur']>>(
            event => {
                setFocused(false);
                onBlur?.(event);
            },
            [onBlur],
        );
        const onPasswordVisibilityToggle = useCallback(() => {
            setVisibility(current => ({ enabled: canTogglePassword, visible: !current.visible }));
        }, [canTogglePassword]);
        const passwordAction = isPasswordVisible ? passwordToggle?.hide : passwordToggle?.show;

        return (
            <View style={[styles.container, containerStyle]}>
                {label ? (
                    <View style={styles.labelContainer}>
                        <Typography
                            {...labelProps}
                            text={label}
                            variant={labelProps?.variant ?? input.typography.labelVariant}
                            color={labelProps?.color ?? input.colors.label}
                            style={labelProps?.style}
                        />
                    </View>
                ) : null}

                <View style={[styles.field, inputContainerStyle]}>
                    {startAccessory != null ? <View style={styles.startAccessory}>{startAccessory}</View> : null}
                    <TextInput
                        {...nativeProps}
                        ref={ref}
                        accessibilityLabel={accessibilityLabel ?? label}
                        accessibilityHint={accessibilityHint ?? (errorText || undefined)}
                        accessibilityState={disabled ? { ...accessibilityState, disabled: true } : accessibilityState}
                        editable={disabled ? false : editable}
                        multiline={multiline}
                        placeholderTextColor={placeholderTextColor ?? colors[input.colors.placeholder]}
                        secureTextEntry={secureTextEntry ? !isPasswordVisible : secureTextEntry}
                        onFocus={onInputFocus}
                        onBlur={onInputBlur}
                        style={[styles.text, multiline && styles.multilineText, style]}
                    />
                    {endAccessory != null ? <View style={styles.endAccessory}>{endAccessory}</View> : null}
                    {canTogglePassword && passwordAction ? (
                        <Pressable
                            accessibilityRole="button"
                            accessibilityLabel={passwordAction.label}
                            disabled={disabled}
                            hitSlop={scaling.scaleHorizontal(12)}
                            onPress={onPasswordVisibilityToggle}
                            style={styles.passwordToggle}
                        >
                            {passwordAction.icon}
                        </Pressable>
                    ) : null}
                </View>

                {errorText ? (
                    <Typography
                        {...errorTextProps}
                        text={errorText}
                        variant={errorTextProps?.variant ?? input.typography.errorVariant}
                        color={errorTextProps?.color ?? input.colors.error}
                        accessibilityRole="alert"
                        accessibilityLiveRegion="polite"
                        style={[styles.supportingText, errorTextProps?.style]}
                    />
                ) : !isInvalid && helperText ? (
                    <Typography
                        {...helperTextProps}
                        text={helperText}
                        variant={helperTextProps?.variant ?? input.typography.helperVariant}
                        color={helperTextProps?.color ?? input.colors.helper}
                        style={[styles.supportingText, helperTextProps?.style]}
                    />
                ) : null}
            </View>
        );
    },
);

InputComponent.displayName = 'Input';

export const Input = memo(InputComponent);
