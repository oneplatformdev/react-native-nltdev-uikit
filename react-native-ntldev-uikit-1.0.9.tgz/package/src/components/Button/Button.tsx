import React, { forwardRef, memo, useCallback, useMemo } from 'react';
import { ActivityIndicator, Pressable, View } from 'react-native';
import type {
    PressableInstance,
    PressableStateCallbackType,
    StyleProp,
    ViewStyle,
} from 'react-native';
import { useUITheme } from '../../theme';
import { useScaling } from '../../utils';
import { Typography } from '../Typography';
import { getStyles } from './styles';
import type { ButtonProps } from './types';

const ButtonComponent = forwardRef<PressableInstance, ButtonProps>(
    (
        {
            accessibilityLabel,
            accessibilityRole,
            accessibilityState,
            children,
            text,
            disabled = false,
            fullWidth = false,
            labelProps,
            leftIcon,
            loading = false,
            loadingAppearance = 'active',
            loadingIndicatorColor,
            rightIcon,
            size = 'md',
            style,
            variant = 'primary',
            ...props
        },
        ref,
    ) => {
        const { button, colors } = useUITheme();
        const scaling = useScaling();
        const variantTheme = button.variants[variant];
        const sizeTheme = button.sizes[size];
        const interactionDisabled = disabled || loading;
        const visuallyDisabled = disabled || (loading && loadingAppearance === 'disabled');
        const textColor = visuallyDisabled ? variantTheme.disabledForeground : variantTheme.foreground;
        const styles = useMemo(
            () => getStyles(colors, scaling, variantTheme, sizeTheme),
            [colors, scaling, sizeTheme, variantTheme],
        );
        const resolveStyle = useCallback(
            ({ pressed }: PressableStateCallbackType): StyleProp<ViewStyle> => {
                const callerStyle = typeof style === 'function' ? style({ pressed }) : style;

                return [
                    styles.container,
                    pressed && !interactionDisabled && styles.pressed,
                    visuallyDisabled && styles.disabled,
                    fullWidth && styles.fullWidth,
                    callerStyle,
                ];
            },
            [fullWidth, interactionDisabled, style, styles, visuallyDisabled],
        );
        const content = text ?? children;
        const isTextChild = typeof content === 'string' || typeof content === 'number';

        return (
            <Pressable
                {...props}
                ref={ref}
                accessibilityLabel={accessibilityLabel ?? (isTextChild ? String(content) : undefined)}
                accessibilityRole={accessibilityRole ?? 'button'}
                accessibilityState={{
                    ...accessibilityState,
                    disabled: interactionDisabled,
                    busy: loading,
                }}
                disabled={interactionDisabled}
                style={resolveStyle}
            >
                <View
                    accessibilityElementsHidden={loading}
                    importantForAccessibility={loading ? 'no-hide-descendants' : 'auto'}
                    style={[styles.content, loading && styles.hidden]}
                >
                    {leftIcon ? <View style={styles.icon}>{leftIcon}</View> : null}
                    {isTextChild ? (
                        <Typography
                            {...labelProps}
                            numberOfLines={labelProps?.numberOfLines ?? button.numberOfLines}
                            color={labelProps?.color ?? textColor}
                            variant={labelProps?.variant ?? sizeTheme.labelVariant}
                            weight={labelProps?.weight ?? sizeTheme.labelWeight}
                            style={[styles.text, labelProps?.style]}
                        >
                            {content}
                        </Typography>
                    ) : (
                        content
                    )}
                    {rightIcon ? <View style={styles.icon}>{rightIcon}</View> : null}
                </View>

                {loading ? (
                    <View pointerEvents="none" style={styles.loader}>
                        <ActivityIndicator color={loadingIndicatorColor ?? colors[textColor]} size="small" />
                    </View>
                ) : null}
            </Pressable>
        );
    },
);

ButtonComponent.displayName = 'Button';

export const Button = memo(ButtonComponent);
