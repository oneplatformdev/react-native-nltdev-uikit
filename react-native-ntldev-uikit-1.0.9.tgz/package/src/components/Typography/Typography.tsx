import React, { forwardRef, memo, useMemo } from 'react';
import type { ReactNode } from 'react';
import { Text } from 'react-native';
import type { TextInstance, TextProps, TextStyle } from 'react-native';
import { useUITheme } from '../../theme';
import type { UIColorKey, UIFontKey, TypographyVariant, UITypographyToken } from '../../theme';
import { useScaling } from '../../utils';

export type TypographyProps = Omit<TextProps, 'children'> & {
    variant?: TypographyVariant;
    weight?: UIFontKey;
    color?: UIColorKey;
    size?: number;
    lineHeight?: number;
} & (
    | { text: string | number; children?: never }
    | { text?: never; children?: ReactNode }
);

const TypographyComponent = forwardRef<TextInstance, TypographyProps>(
    (
        {
            text,
            children,
            variant = 'body',
            weight,
            color = 'text',
            size,
            lineHeight,
            style,
            ...props
        },
        ref,
    ) => {
        const { colors, fonts, typography } = useUITheme();
        const scaling = useScaling();
        const token = typography[variant] as UITypographyToken;
        const font = fonts[weight ?? token.font];
        const resolvedLineHeight = lineHeight ?? token.lineHeight;

        const resolvedStyle = useMemo<TextStyle>(
            () => ({
                ...font,
                color: colors[color],
                fontSize: scaling.scaleFontSize(size ?? token.fontSize),
                lineHeight:
                    resolvedLineHeight === undefined
                        ? undefined
                        : scaling.scaleLineHeight(resolvedLineHeight),
                letterSpacing: token.letterSpacing,
                includeFontPadding: token.includeFontPadding,
                flexShrink: token.flexShrink,
            }),
            [color, colors, font, resolvedLineHeight, scaling, size, token],
        );

        return <Text ref={ref} {...props} style={[resolvedStyle, style]}>{text ?? children}</Text>;
    },
);

TypographyComponent.displayName = 'Typography';

export const Typography = memo(TypographyComponent);
